// Milan Haydel
// C00419477
// CMPS 260
// Programming Assignment : 4
// Due Date : Oct 25, 2020
// Program Description: This assignment models a photograph and camera
//  in two classes to emphasize the concepts of object-oriented programming
//  and composition.
// Certificate of Authenticity:
// I certify that the code in the Main, Photograph, and Camera classes
// of this project is entirely my own work with the exception of the
// provided factory methods.
package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args){

        Photograph all = Photograph.createAll255sPhotograph();
        Photograph min = Photograph.createMinimumPhotograph();
        Photograph checkerBoard = Photograph.create7x7Checkerboard();

        System.out.println("createAll255sPhotograph Factory: " + all.getPixel() + " " + all.getDate());
        System.out.println("createMinimumPhotograph Factory: " + min.getPixel() + " " + min.getDate());
        System.out.println("create7x7Checkerboard Factory: " + checkerBoard.getPixel() + " " + checkerBoard.getDate());

    }
}
