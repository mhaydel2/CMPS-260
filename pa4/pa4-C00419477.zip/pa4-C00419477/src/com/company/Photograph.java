package com.company;

public class Photograph {
    private String date;
    private int[] pixelArray;


    // default size and date (c)
    Photograph(){
        pixelArray = new int[100];
        date = "19000101";
    }

    Photograph(int newSize, String date){
        pixelArray = new int[newSize];
        this.date = date;
    }


    // changes the value for the given index of the pixel to 'value' as long as both are valid (b)
    public void setPixel(int index, int value) {
        if (this.getPixel()-1 >= index && index >= 4 && value >= 0 && value <= 255){
            this.pixelArray[index] = value;
        }
    }

    // accessor (getter) (b)

    public int getPixel() {
        return pixelArray.length;
    }

    public String getDate() {
        return date;
    }


    //Factory Methods (e)

    public static Photograph createAll255sPhotograph() {
        Photograph p = new Photograph(100, "19000101");
        for(int i=0; i < p.pixelArray.length; i++) {
            p.pixelArray[i] = 255; }
        return p;
    }
    public static Photograph createMinimumPhotograph() {
        return new Photograph(4, "19000102");
    }
    public static Photograph create7x7Checkerboard() {
        Photograph p = new Photograph(49, "19000103");
        for(int i=0; i < p.pixelArray.length; i++) {
            if(i%2 == 0)
                p.pixelArray[i] = 255;
            else
                p.pixelArray[i] = 0;
        }
        return p;
    }
}
