// Milan Haydel
// C00419477
// CMPS 260
// Programming Assignment : 3
// Due Date : October 21,2020 Wednesday
// Program Description: This assignment collects the topics from the last two programming assignment
// and includes the most recently covered topics: methods and arrays.
// Certificate of Authenticity: (choose one from below)
// I certify that the code in the method function main of this project // is entirely my own work.
package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        loop();

        System.out.print("Enter a value for a: ");
        float a = input.nextFloat();
        System.out.print("Enter a value for b: ");
        float b = input.nextFloat();
        System.out.print("Enter a value for c: ");
        float c = input.nextFloat();
        float[] x = new float[2];
        quadratic(new float[]{a, b, c});
        System.out.print(x[0]);
        System.out.print(x[1]);



    }

    public static void loop() {
        for (int i = 1; i <= 4; i++) {
            System.out.println(i + ": All work and no play makes Jack a dull boy.");
        }
    }

    public static float[] quadratic(float[] array) {
        float x[] = new float[2];
        if ((Math.pow(array[1], 2)) - (4 * array[0] * array[2]) > 0) {
            x[0] = (float) (-array[1]+Math.sqrt(array[1]-4*array[0]*array[2]))/2*array[0];
            x[1] = (float) (-array[1]-Math.sqrt(array[1]-4*array[0]*array[2]))/2*array[0];
        }
        else {
            x[0] = (float) 0.0;
            x[1] = (float) 0.0;
        }
        return x;
    }

    public static void strings()

}
